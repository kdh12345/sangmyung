#include <stdio.h>
#define STUDENT 44

typedef struct student
{
	char name[30];
	char sex;
	char area[30];
	char major[30];
	double scoreaverage;
	int tall;
	int weight;
}Student;
int main(void)
{
	FILE*fp;
	fopen_s(&fp,"list.txt","rt");
	int ret;
	Student std[STUDENT];
	int i=0;
	if(fp==NULL)
	{
		puts("���Ͽ��½���!");
		return -1;
	}
	for(i=0;i<STUDENT;i++)
	{
		ret=fscanf_s(fp,"%s %c %s %s %lf %d %d",std[i].name,30,&std[i].sex,1,std[i].area,30,std[i].major,30,&std[i].scoreaverage,&std[i].tall,&std[i].weight);//���ڳ� ���ڿ��� ũ�⸦ ǥ���Ұ�
		if(ret==EOF)
			break;
		printf("%s %c %s %s %.2lf %d %d",std[i].name,std[i].sex,std[i].area,std[i].major,std[i].scoreaverage,std[i].tall,std[i].weight);
		printf("\n");
	}
	fclose(fp);
	return 0;
}





