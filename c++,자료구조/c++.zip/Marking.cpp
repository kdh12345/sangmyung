#include <iostream>
using namespace std;

class Stu{
private:
	char*name;
	int hno;
	int score;
	int rn;
public:
	Stu(const char*name,int _hno,int _score):hno(_hno),score(_score){
		this->name=new char[strlen(name)+1];
		strcpy(this->name,name);
	}
	
	~Stu(){
		delete[]name;
	}