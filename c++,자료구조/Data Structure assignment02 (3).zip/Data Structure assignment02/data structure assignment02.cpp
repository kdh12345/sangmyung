#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define STUDENT 100

typedef struct student
{
   char name[30];
   char sex;
   char area[30];
   char major[30];
   double scoreaverage;
   int tall;
   int weight;
}Student;
typedef struct input
{
	char order[30];
	char name[30];
	char sex;
	char area[30];
   char major[30];
   char scoreaverage[30];
   char tall[30];
   char weight[30];
}Input;
int count_stduent(FILE*fp)
{
   char str[256];
   int i = 0;
   while (fgets(str, 256, fp) != NULL)
      i++;
   return i;
}

void Swap(Student * a, Student * b);
void Inputt(Input*f2)
{
	FILE*fp;
	fopen_s(&fp,"input.txt","rt");
	int n;
	int i;
   n = count_stduent(fp);
   rewind(fp);
   Input*iut;
   iut = (Input*)calloc(n, sizeof(Input));
	for(i=0;i<n;i++)
	{
		fscanf_s(fp,"%s %s %s %s %lf %d %d",iut[i].order,30,iut[i].name,30,iut[i].sex,1,iut[i].area,30,iut[i].major,30,iut[i].scoreaverage,iut[i].tall,iut[i].weight);
	}
}
	
/*void Add(Input*f2)
{
	
	FILE*fp;
	fopen_s(&fp,"list.txt","a");
	Input*sti;
	int n;
   n = count_stduent(fp);
   rewind(fp);
   int i;
  for(i=0;i<n;i++)
  {
	  Inputt(&sti[i]);
  }
	   sti=(Input*)calloc(n,sizeof(Input));
		fprintf(fp,sti[3].name);
		fputc(f2[3].sex,fp);
		fprintf(fp,sti[3].area);
		fprintf(fp,sti[3].major);
		fprintf(fp,sti[3].scoreaverage);
		fprintf(fp,sti[3].tall);
		fprintf(fp,sti[3].weight);
		fprintf(fp,"\n");;// �ʿ�� �ٽ� ����
		fprintf(fp,sti[4].name);
		fputc(sti[4].sex,fp);
		fprintf(fp,sti[4].area);
		fprintf(fp,sti[4].major);
		fprintf(fp,sti[4].scoreaverage);
		fprintf(fp,sti[4].tall);
		fprintf(fp,sti[4].weight);
	
}*/


/*void Delete(Student*f2,int m)
{
	FILE*fp;
	fopen_s(&fp, "input.txt", "rt");
	int n;
	n= count_stduent(fp);
	rewind(fp);
	Student*std;
	std=(Student*)calloc(n,sizeof(Student));
	std=(Student*)realloc(std,sizeof(Student));
	int i;
	for(i=0;i<n;i++)
	{
		std[i]=std[i+1];
	}

}*/

/*void Search(Student*f3,int p)
{
	FILE*fp;
	fopen_s(&fp, "input.txt", "rt");
	int n;
	n= count_stduent(fp);
	rewind(fp);
	Student*std;
	std=(Student*)calloc(n,sizeof(Student));
	std=(Student*)realloc(std,sizeof(Student));
	int i;
	for(i=0;i<n;i++)
	{*/
		
			
			
int main(void)
{

   FILE*fp;
   fopen_s(&fp, "list.txt", "rt");
   int ret;
   Student *std;
   //Input*sti;
   int i, j;
   if (fp == NULL)
   {
      puts("���Ͽ��½���!");
      return -1;
   }
   int n;
   n = count_stduent(fp);
   rewind(fp);
   std = (Student*)calloc(n, sizeof(Student));
   //sti=(Input*)calloc(n,sizeof(Input));
   for (i = 0; i < n; i++)
   {

      ret = fscanf_s(fp, "%s %c %s %s %lf %d %d", std[i].name, 30, &std[i].sex, 1, std[i].area, 30, std[i].major, 30, &std[i].scoreaverage, &std[i].tall, &std[i].weight);//���ڳ� ���ڿ��� ũ�⸦ ǥ���Ұ�
      if (ret == EOF)
         break;
   }

   for (i = 0; i < n; i++)
   {
      for (j = 0; j < n - 1; j++)
      {
         if (strcmp(std[i].name, std[j].name) < 0)
         {  
			Swap(&std[i],&std[j]);
		 }
      }
   }
   for (i = 0; i < n; i++)
   {
      printf("%s %c %s %s %.2lf %d %d", std[i].name, std[i].sex, std[i].area, std[i].major, std[i].scoreaverage, std[i].tall, std[i].weight);
      printf("\n");
   }
	/*for(i=0;i<n;i++)
   {
	  for(j=0;j<n-1;j++)
	  {
		
	   if(i==2&&i==37)
	   {
		   fopen_s(&fp,"list.txt","a");
		   std=(Student*)realloc(std,sizeof(Student));
		   fprintf(fp,"�赿�� M ���� ��ǻ�Ͱ��а� 3.10 181 75");
		   fprintf(fp,"������ M ��õ ������а� 3.33 175 69");
	   }
	    if (strcmp(std[i].name, std[j].name) < 0)
         {  
			Swap(&std[i],&std[j]);
		 }
	  printf("%s %c %s %s %.2lf %d %d", std[i].name, std[i].sex, std[i].area, std[i].major, std[i].scoreaverage, std[i].tall, std[i].weight);
      printf("\n");
	}
	}*/
	

   free(std);
   fclose(fp);
   return 0;
}


void Swap(Student * a, Student * b)
{
   Student temp = *a;
   *a = *b;
   *b = temp;
}